firstname = input()
lastname = input()
if (len(firstname)<=10) and (len(lastname)<=10):
    print(f"Hello {firstname} {lastname}! You just delved into python.")
