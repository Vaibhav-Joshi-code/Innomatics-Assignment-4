s = input()
print(s)
s = s[:5]+"k"+s[6:]
print(s)
