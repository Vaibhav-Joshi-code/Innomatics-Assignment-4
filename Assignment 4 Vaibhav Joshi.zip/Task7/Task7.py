s = input()
print(s.title())

