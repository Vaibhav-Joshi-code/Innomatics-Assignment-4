s = input()
print(s.swapcase())
