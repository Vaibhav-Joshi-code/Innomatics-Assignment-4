s = input()
if (len(s)>0) and (len(s)<1000):
    print(s.isalnum())
    print(s.isalpha())
    print(s.isdigit())
    print(s.islower())
    print(s.isupper())
