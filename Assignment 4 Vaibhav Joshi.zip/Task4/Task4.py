s = input()
sub = input()
print(s.count(sub))
